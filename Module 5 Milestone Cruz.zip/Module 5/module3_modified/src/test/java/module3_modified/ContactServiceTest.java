//Cruz Matthew 12/1/2024

package module3_modified; // Defines the package for the class

import org.junit.jupiter.api.Test; // Imports the Test annotation for JUnit tests
import java.util.Date; // Imports Date for reminder testing

import module03_modified.Contact; // Imports the Contact class
import module03_modified.ContactService; // Imports the ContactService class

import static org.junit.jupiter.api.Assertions.*; // Imports assertions for test validation

// Test class for the ContactService class
public class ContactServiceTest {

    // Test to verify that a contact can be added to the ContactService
    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService

        // Asserts that the contact ID "1234567890" exists in the contacts map after addition
        assertTrue(contactService.getContacts().containsKey("1234567890"));
    }

    // Test to verify that a contact can be deleted from the ContactService
    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService
        contactService.deleteContact("1234567890"); // Deletes the contact by its ID

        // Asserts that the contact ID "1234567890" no longer exists in the contacts map after deletion
        assertFalse(contactService.getContacts().containsKey("1234567890"));
    }

    // Test to verify that a contact's details can be updated in the ContactService
    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService

        // Updates the contact's first name to "Jane" while keeping other details the same
        contactService.updateContact("1234567890", "Jane", "Doe", "1234567890", "123 Main St");

        // Asserts that the contact's first name is updated to "Jane"
        assertEquals("Jane", contactService.getContacts().get("1234567890").getFirstName());
    }

    // Test to verify that a contact's phone number can be updated in the ContactService
    @Test
    public void testUpdatePhoneNumber() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService

        // Updates the contact's phone number to a new number
        contactService.updatePhoneNumber("1234567890", "0987654321");

        // Asserts that the contact's phone number is updated to "0987654321"
        assertEquals("0987654321", contactService.getContacts().get("1234567890").getPhone());
    }

    // Test to verify that a contact can be retrieved from the ContactService by ID
    @Test
    public void testGetContactById() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService

        // Retrieve the contact by ID and assert the contact's first name is "John"
        Contact retrievedContact = contactService.getContact("1234567890");
        assertEquals("John", retrievedContact.getFirstName());
    }

    // Test to verify that a contact's reminder can be set in the ContactService
    @Test
    public void testSetReminder() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService

        Date reminderDate = new Date(System.currentTimeMillis() + 10000000); // Set a reminder for a future date
        boolean reminderSet = contactService.setReminder("1234567890", reminderDate); // Set the reminder

        // Asserts that the reminder was set successfully
        assertTrue(reminderSet);
        // Asserts that the reminder time for the contact is the same as the one set
        assertEquals(reminderDate, contactService.getReminder("1234567890"));
    }

    // Test to verify that a contact's reminder can be retrieved in the ContactService
    @Test
    public void testGetReminder() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St"); // Creates a new Contact instance
        contactService.addContact(contact); // Adds the contact to the ContactService

        Date reminderDate = new Date(System.currentTimeMillis() + 10000000); // Set a reminder for a future date
        contactService.setReminder("1234567890", reminderDate); // Set the reminder

        // Retrieve the reminder and assert that the retrieved reminder date matches the expected one
        Date retrievedReminder = contactService.getReminder("1234567890");
        assertEquals(reminderDate, retrievedReminder);
    }

    // Test to verify that an invalid reminder attempt fails
    @Test
    public void testSetReminderForNonExistentContact() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance

        Date reminderDate = new Date(System.currentTimeMillis() + 10000000); // Set a reminder for a future date
        boolean reminderSet = contactService.setReminder("nonexistentID", reminderDate); // Try to set a reminder for a non-existent contact

        // Asserts that the reminder was not set for a non-existent contact
        assertFalse(reminderSet);
    }

    // Test to verify that getting a reminder for a non-existent contact returns null
    @Test
    public void testGetReminderForNonExistentContact() {
        ContactService contactService = new ContactService(); // Creates a new ContactService instance

        Date reminder = contactService.getReminder("nonexistentID"); // Try to get a reminder for a non-existent contact

        // Asserts that the reminder is null for a non-existent contact
        assertNull(reminder);
    }
}
