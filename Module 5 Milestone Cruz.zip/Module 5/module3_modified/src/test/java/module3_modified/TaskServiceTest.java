//Cruz Matthew 12/1/2024

package module3_modified; // Defines the package for the class

import org.junit.jupiter.api.Test; // Imports JUnit's Test annotation for unit tests
import module03_modified.Task;
import module03_modified.TaskService;

import static org.junit.jupiter.api.Assertions.*; // Imports assertion methods for validating test results

import java.util.Map;

// Test class to validate the functionality of TaskService methods
public class TaskServiceTest {

    // Test case to verify the addTask method works as expected
    @Test
    public void testAddTask() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        assertEquals(task, taskService.getTask("1234567890")); // Asserts that the task retrieved matches the added task
    }

    // Test case to verify the deleteTask method works as expected
    @Test
    public void testDeleteTask() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        taskService.deleteTask("1234567890"); // Deletes the task using its ID
        assertNull(taskService.getTask("1234567890")); // Asserts that the task is no longer in the TaskService (should be null)
    }

    // Test case to verify the updateTaskName method works as expected
    @Test
    public void testUpdateTaskName() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        taskService.updateTaskName("1234567890", "NewTaskName"); // Updates the task's name
        assertEquals("NewTaskName", taskService.getTask("1234567890").getName()); // Asserts that the task's name was updated
    }

    // Test case to verify the updateTaskDescription method works as expected
    @Test
    public void testUpdateTaskDescription() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        taskService.updateTaskDescription("1234567890", "NewTaskDescription"); // Updates the task's description
        assertEquals("NewTaskDescription", taskService.getTask("1234567890").getDescription()); // Asserts that the task's description was updated
    }

    // Test case to verify that markTaskAsCompleted works as expected
    @Test
    public void testMarkTaskAsCompleted() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        taskService.markTaskAsCompleted("1234567890"); // Marks the task as completed
        assertTrue(taskService.getTask("1234567890").isCompleted()); // Asserts that the task is marked as completed
    }

    // Test case to verify that the task can be retrieved using getTask method
    @Test
    public void testGetTask() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        
        // Retrieves the task using its ID and asserts that the task is correct
        Task retrievedTask = taskService.getTask("1234567890");
        assertEquals(task, retrievedTask); // Asserts that the task retrieved matches the task added
    }

    // Test case to verify the getTasksByCompletionStatus method works as expected
    @Test
    public void testGetTasksByCompletionStatus() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task1 = new Task("1234567890", "Task1", "Description1"); // Creates a new Task object
        Task task2 = new Task("0987654321", "Task2", "Description2"); // Creates another Task object
        taskService.addTask(task1); // Adds the first task to the TaskService
        taskService.addTask(task2); // Adds the second task to the TaskService

        taskService.markTaskAsCompleted("1234567890"); // Marks the first task as completed
        Map<String, Task> completedTasks = taskService.getTasksByCompletionStatus(true); // Retrieves completed tasks
        Map<String, Task> notCompletedTasks = taskService.getTasksByCompletionStatus(false); // Retrieves non-completed tasks

        assertTrue(completedTasks.containsKey("1234567890")); // Asserts the completed task is present in the filtered tasks
        assertTrue(notCompletedTasks.containsKey("0987654321")); // Asserts the non-completed task is present in the filtered tasks
    }

    // Test case to verify the printAllTasks method works as expected
    @Test
    public void testPrintAllTasks() {
        TaskService taskService = new TaskService(); // Creates an instance of TaskService
        Task task = new Task("1234567890", "TaskName", "TaskDescription"); // Creates a new Task object
        taskService.addTask(task); // Adds the task to the TaskService
        
        // Verify the print output (could be captured if necessary, or checked manually)
        taskService.printAllTasks(); // Prints all tasks
    }
}